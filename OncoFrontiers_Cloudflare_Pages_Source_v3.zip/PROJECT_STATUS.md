# ONCOFRONTIER — Release Verification

Checked: 2026-10-20. The live Cloudflare Pages URL is `https://oncofrontier-research-intelligence-app.pages.dev/`. The existing deployment contains the previously published UI/accessibility/SEO work; this source revision adds the clinical-trial query repair and still needs a fresh deployment.

## Verification matrix

| Area | Status | Evidence / limitation |
|---|---|---|
| TypeScript | PASS | `npm run typecheck` passes on the local source. |
| ESLint | PASS | `npm run lint` passes on the local source. |
| Unit tests | BLOCKED | `npm test` cannot start Vitest: Windows denies esbuild child-process launch (`spawn EPERM`). The new query-mapping tests are included but unverified locally. |
| Production build | BLOCKED LOCALLY | `npm run build` fails before compilation for the same `spawn EPERM`. Cloudflare successfully built the preceding Pages archive; the new archive must build before this change is confirmed live. |
| Hosted app entry | PASS | Cloudflare Pages URL loaded and rendered dashboard, accessibility settings, and companion chat. |
| Display/accessibility controls | PARTIAL | Live settings panel opened. Blindness Support toggled larger text, listening mode, voice guide, and larger touch targets; Reset restored their original off state. No screen-reader or full keyboard audit was completed. |
| Live evidence search | FIX PENDING DEPLOY | Live query “EGFR resistance lung cancer” returned unrelated trial records. This source now sends free-text, condition, and intervention terms to the matching ClinicalTrials.gov API fields; verify after a fresh Pages build. |
| Source integrations | PARTIAL | Source code uses public PubMed, Europe PMC, ClinicalTrials.gov, Crossref, OpenAlex, Open Targets, and PubChem APIs. Live search returned records; each provider's current health and relevance were not separately verified in this pass. |
| Research assistant | PARTIAL | Local assistant is retrieval and formatting, not generative AI; results link to source records. Evidence comparison and source-passage-grounded synthesis are not implemented. |
| PDF reader | PARTIAL | Local PDF text extraction and keyword passage search; scanned-page OCR, rendered page navigation, highlights, annotations, bookmarks, and citation capture are not implemented. File selection is now keyboard reachable, but that change was not browser-tested. |
| Companion AI chat | PARTIAL | The edge function keeps the model key server-side. Local code now verifies a signed-in Supabase user before the configured LLM call and avoids repeating failed model calls; guests retain public retrieval. Both chat views disclose search/AI provider processing and avoid-identifier guidance. The changed edge function has not been deployed or end-to-end tested. Provider-side limits are still required; application rate limiting is absent. |
| Voice and listening | PARTIAL | Browser speech recognition/synthesis and explicit Puter-based audio fallback exist. Support varies by browser, device, installed voices, and network. No microphone hardware test was performed. |
| Accessibility implementation | PARTIAL | Four presets and persistent display settings exist. A keyboard skip link, modal focus handling, and accessible PDF upload were added locally. No NVDA, VoiceOver, TalkBack, WCAG audit, color-simulation audit, or mobile assistive-technology test was performed. |
| Interface languages | PARTIAL | English, French, and Arabic have full resources. Sixteen more locales have partial core translations with English fallback for longer content. Tunisian Arabic shares Arabic UI. Translation tests check selected strings but could not run; no linguistic review was performed. Do not advertise “20 languages supported.” |
| Saved data and RLS | PARTIAL | Local migrations scope user tables to `auth.uid()`. No safe live sign-in, cross-account isolation, storage-policy, backup, or current Supabase security-advisor test was run. |
| Automations | PARTIAL | Saved searches can be checked manually in the app; there is no verified background scheduler or email delivery. |
| SEO/public metadata | PARTIAL | Build-time script now points canonical, Open Graph/Twitter, robots, and sitemap metadata at Netlify's configured public URL (or `PUBLIC_SITE_URL`). Not deployed or crawl/index tested; hash routes are not separate crawlable pages. |
| Public legal/support pages | BLOCKED | Approved Privacy, Terms, Contact, and account-deletion information are absent. Do not invite public accounts until these are supplied. |
| Poster discovery and templates | NOT TESTED | No verified global poster-search workflow or complete reusable template library was found in this pass. |
| Promotional PDF | PARTIAL | Existing demo PDF is one page and describes 3 full interface translations plus 16 partial locales. Text/page count checked; no new render was made in this pass. |

## Changes in this repair

- Kept the Heart companion launcher and open chat on the physical right edge with safe-area spacing, including one-handed mode (`src/components/FloatingCompanion.tsx`, `src/index.css`).
- Added a localized skip-to-main-content link and made the PDF upload control keyboard reachable, with accessible progress and error announcements.
- Added focus placement, Escape handling, and Tab containment to the display/accessibility dialog.
- Changed the dashboard metric to the three complete interface translations instead of claiming all 20 language options are fully supported.
- Added build-time canonical/social metadata and sitemap generation from the actual hosting domain; no Bolt URL remains hard-coded in app metadata.
- Fixed ClinicalTrials.gov search field mapping so free-text questions and gene terms are no longer ignored; added regression tests in `src/test/clinicaltrials.test.ts`.
- Required a verified signed-in Supabase user for configured server-side AI chat; public retrieval stays available to guests. Removed an immediate duplicate AI request after failure.
- Added translated Companion privacy notices before chat input and made the PDF reader's upload, progress, and errors accessible to keyboard and assistive-technology users.
- Corrected deployment and product documentation to disclose partial translations, unavailable features, provider dependencies, and public-release blockers.
- Added a Netlify-aware post-build SEO sync and GitHub Actions checks workflow. Both still require a hosted build to verify.
- Removed privileged Supabase service-role/database entries from `.env.example`; the submission ZIP excludes the local `.env` file.

## Privacy/security notes

- The submission archive excludes `.env`, `node_modules`, `dist`, `.bolt`, and `.git`; `.env.example` contains placeholders only.
- Database RLS was reviewed statically in the local migrations; remote policy state was not inspected in this pass.
- Companion LLM requests and local retrieval have different data flows. User-started Puter image/audio/TTS features may transmit content to that provider; explain this to users before public launch.
- The Edge Function still needs deployed auth changes, provider usage limits, and abuse/rate-limit controls before enabling an LLM secret publicly.

## Release recommendation: NOT READY

Release remains pending the fresh Cloudflare build and search retest. Unit tests and a local production build are blocked by Windows `spawn EPERM`; typecheck and lint pass. Approved privacy/terms/support information, abuse controls, and end-to-end account isolation checks remain launch blockers for public accounts. Google indexing and ranking have not been verified or guaranteed. The repository previously showed `.env`; rotate any exposed credentials and remove them from Git history before public launch.
